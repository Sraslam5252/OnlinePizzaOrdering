package com.wipro.model;

public class Store {
//	String StoreID;
	String StoreName;
	
	String Address;
	String PhoneNumber;
//	public String getStoreID() {
//		return StoreID;
//	}
//	public void setStoreID(String storeID) {
//		StoreID = storeID;
//	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getStoreName() {
		return StoreName;
	}
	public void setStoreName(String storeName) {
		StoreName = storeName;
	}
	
	

}
