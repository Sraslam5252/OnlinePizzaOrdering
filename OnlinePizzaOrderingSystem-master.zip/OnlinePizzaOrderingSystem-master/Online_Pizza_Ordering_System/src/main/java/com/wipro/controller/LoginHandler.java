package com.wipro.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginHandler
 */
@WebServlet("/Login")
public class LoginHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String choice = request.getParameter("choice");
		request.setAttribute("choice", choice);
		if(choice.equals("user")) {
			request.getRequestDispatcher("./userlogin.jsp").forward(request, response);
			request.getSession().setAttribute("user", choice);
		}
		else if (choice.equals("admin")) {
			request.getRequestDispatcher("./adminlogin.jsp").forward(request, response);
			request.getSession().setAttribute("admin", choice);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
